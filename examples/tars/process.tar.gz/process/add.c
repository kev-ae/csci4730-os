#include <stdio.h>

int main()
{
		int a, b; 
		
		a = 10;
		b = 20;

		b = a + b;

		printf("b = %d\n", b);
		return b;
}

